package com.client;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.daoimpl.StudentServiceImpl;
import com.model.Student;

public class Access {

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		ApplicationContext context= new ClassPathXmlApplicationContext("springbean.xml");
		StudentServiceImpl s=(StudentServiceImpl) context.getBean("stuSerImp");
		Student stu=new Student();
		stu.setId(4);
		stu.setSname("ravi");
		stu.setCourse("javaspring");
		stu.setFee(2233);
		s.addStu(stu);
		List<Student> st=s.fetchAllStudents();
		for(Student ss: st)
			System.out.println(ss.getId()+" "+ss.getFee()+" "+ss.getSname()+" "+ss.getCourse());	
		s.updateCourseById("python", 1);
		s.delStuById(4);
		}
}
