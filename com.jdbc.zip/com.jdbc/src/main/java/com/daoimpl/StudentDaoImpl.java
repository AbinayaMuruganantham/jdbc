package com.daoimpl;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;

import java.sql.Connection;
import java.util.List;

import com.dao.StudentDao;
import com.model.Student;

public class StudentDaoImpl implements StudentDao
{
	DataSource dataSource;
	JdbcTemplate jdbcTemplate;
	
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		this.jdbcTemplate=new JdbcTemplate(dataSource);
	}
	
	//UMIMPLEMENTED METHODS
	public void insertStu(Student stu)
	{
		// TODO Auto-generated method stub
		String s="insert into Student(id,sname,course,fee) values(?,?,?,?)";
		int insert=jdbcTemplate.update(s,new Object[] {stu.getId(),stu.getSname(),stu.getCourse(),stu.getFee()});
		if(insert>0)
				System.out.println("data successfully inserted");
	}
	public Student getStuById(int stuId)
	{
		// TODO Auto-generated method stub
		String s="select * from Student where id=?";
		Student stu=jdbcTemplate.queryForObject(s,new StudentRowMapper(),stuId);
		return stu;
	}
	public void deleteStuById(int stuId) 
	{
		// TODO Auto-generated method stub
		String s ="delete from Student where id=?";
		int q=jdbcTemplate.update(s,stuId);
		if(q>0)
			System.out.println("deleted the data successfullyyy...");
	}
	public void updateStuCourseById(String newCourse, int StudentId) 
	{
		// TODO Auto-generated method stub
	    String s="update Student set course=? where id=?";
	    int q=jdbcTemplate.update(s,newCourse,StudentId);
	    if(q>0)
			System.out.println("updated the data successfullyyy...");
	    
	}
	public List<Student> getAllStudents() 
	{
		// TODO Auto-generated method stub
		String s="select * from Student";
		List<Student>stus=jdbcTemplate.query(s, new StudentRowMapper());
		return stus;
	}
	
	
	

}
