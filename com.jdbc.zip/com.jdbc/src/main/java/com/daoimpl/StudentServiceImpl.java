package com.daoimpl;

import java.util.List;

import com.dao.StudentDao;
import com.dao.StudentService;
import com.model.Student;

public class StudentServiceImpl implements StudentService
{
	StudentDao studentDao;
	

	public void setStudentDao(StudentDao studentDao) {
		this.studentDao = studentDao;
	}

	public void addStu(Student stu)
	{
		// TODO Auto-generated method stub
		studentDao.insertStu(stu);	
	}

	public Student fetchStuById(int stuId) 
	{
		// TODO Auto-generated method stub
		return studentDao.getStuById(stuId);
	}

	public void delStuById(int stuId)
	{
		// TODO Auto-generated method stub
		studentDao.deleteStuById(stuId);
		
	}
	public void updateCourseById(String newCourse, int Stuid)
	{
		// TODO Auto-generated method stub
		studentDao.updateStuCourseById(newCourse, Stuid);
		
	}

	public List<Student> fetchAllStudents() {
		return studentDao.getAllStudents();
	}
	

}
