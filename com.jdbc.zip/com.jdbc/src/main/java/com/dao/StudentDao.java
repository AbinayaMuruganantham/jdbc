package com.dao;

import java.util.List;

import com.model.Student;

public interface StudentDao 
{
	void insertStu(Student stu);
	Student getStuById(int stuId);
	void deleteStuById(int stuId);
	void updateStuCourseById(String newCourse,int StudentId );
	List<Student> getAllStudents();
	

}
