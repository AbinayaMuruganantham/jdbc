package com.dao;

import java.util.List;

import com.model.Student;

public interface StudentService
{
	void addStu(Student stu);
	Student fetchStuById(int stuId);
	void delStuById(int stuId);
	void updateCourseById(String newCourse,int Stuid);
	List<Student> fetchAllStudents();

}
